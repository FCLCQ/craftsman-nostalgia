# 第三方资源声明

本资源包整体采用 CC BY-SA 4.0，只包含以下来源中与源文件逐字节一致的素材。

## 包含来源

| 资源包 | 作者 | 许可 | 条目 |
|---|---|---|---|
| ModernityExtra | RuiXuqi | MIT | 755 |
| Backport Everything 1.12-1.12.2 v1.8 | samfortyseven | CC BY-SA 4.0 | 1082 |

MIT 素材保留原始许可；CC BY-SA 4.0 素材再分发时需要署名并以相同方式共享。

Backport Everything 的部分素材来自 Qwuiblington 的 actually correct 1.14 texture backport。Minecraft 原版素材版权归 Mojang Studios，随包用于游戏内显示，不在 CC BY-SA 4.0 授权范围内。

## 未采用的素材

Modernity-f3 3.10.3 采用 LGPL-3.0-only，与整包 CC BY-SA 4.0 不兼容，未引入；对应的原版贴图覆盖由 Backport Everything 提供。

## 计划引入的素材

以下素材计划在取得授权或改用许可兼容的替代素材后引入，用于补齐观感、音效与语言，不列入当前包。

| 来源 | 作者 | 当前状态 |
|---|---|---|
| FFD Additional Resource Pack 1.1 | xy177 | 未附许可文件，待授权 |
| Modernity Adjunct | RuiXuqi 等 | LGPL-2.1，待授权或改用兼容许可 |
| Fabric Chests | anner | GPL-3.0，待授权或改用兼容许可 |

## 使用与分发

再分发本资源包时必须保留本声明并按 CC BY-SA 4.0 署名、相同方式共享。MIT 素材保留原始许可。
