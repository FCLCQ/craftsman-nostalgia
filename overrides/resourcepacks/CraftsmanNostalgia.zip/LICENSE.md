# 许可证

本资源包整体采用 Creative Commons 署名-相同方式共享 4.0 国际（CC BY-SA 4.0）许可，见 https://creativecommons.org/licenses/by-sa/4.0/ 。

包含的 MIT 许可素材保留其原始 MIT 授权，列入 THIRD-PARTY-NOTICES.md。整合包作者自行编写的部分在此一并按 CC BY-SA 4.0 发布。

第三方模组与材质版权归各自作者，详见 THIRD-PARTY-NOTICES.md。

包内含 Minecraft 原版素材，版权归 Mojang Studios，仅在 Minecraft 资源包范围内随包分发。
